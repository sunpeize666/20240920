var hi = 'hello';

function greeting() {
    document.write(`${hi}`);
}

// 함수 호출
greeting();